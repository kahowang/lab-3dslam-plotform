imu_filter_madgwick
===================

A fork for the purposes of releasing into Clearpath's debian
packages to install on Jackal.
